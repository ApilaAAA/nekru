import os
import atexit
import requests
import threading
import time
from flask import Flask, request

app = Flask(__name__)

# ===== CONFIG =====
WEBHOOK_URL = os.environ.get("DISCORD_WEBHOOK", "https://discord.com/api/webhooks/XXXX/XXXX")
PORT = int(os.environ.get("PORT", 8080))
PUBLIC_URL = os.environ.get("PUBLIC_URL")  # Optional, set this on the host if available
PROJECT_NAME = os.environ.get("PROJECT_NAME")  # optional (used to guess bot-hosting.net subdomain)
# ==================

# Stats
visitor_ips = set()
total_requests = 0
request_log = {}  # {ip: [timestamps]}
error_log = {}    # {ip: error_count}

# Detection thresholds (tune as needed)
DDOS_THRESHOLD = 50   # requests
DDOS_WINDOW = 10      # seconds
ERROR_THRESHOLD = 10  # errors per IP

def send_webhook(message: str):
    """Send a log message to Discord."""
    try:
        requests.post(WEBHOOK_URL, json={"content": message}, timeout=5)
    except Exception as e:
        print(f"[Webhook error] {e}")

def get_public_url(port=PORT):
    """
    Try to determine a public URL for the running site and print it.
    Preference order:
      1. PUBLIC_URL env variable (recommended)
      2. PROJECT_NAME -> guess https://{project}.bot-hosting.net
      3. Any common env vars (HOSTNAME, APP_URL, DOMAIN)
      4. Fallback to local IP with port
    """
    # 1. explicit env var
    if PUBLIC_URL:
        return PUBLIC_URL.rstrip("/")
    # 2. project name guess
    if PROJECT_NAME:
        return f"https://{PROJECT_NAME}.bot-hosting.net"
    # 3. common env vars to try
    for k in ("APP_URL", "DOMAIN", "HOSTNAME", "URL", "BASE_URL"):
        v = os.environ.get(k)
        if v:
            return v.rstrip("/")
    # 4. try to guess local network IP
    try:
        import socket
        hostname = socket.gethostname()
        local_ip = socket.gethostbyname(hostname)
        return f"http://{local_ip}:{port}"
    except Exception:
        return f"http://0.0.0.0:{port}"

@app.before_request
def log_request():
    """Log all incoming requests before handling them."""
    global total_requests
    ip = request.headers.get("X-Forwarded-For", request.remote_addr)
    ua = request.headers.get("User-Agent", "Unknown")
    method = request.method
    path = request.path

    total_requests += 1
    visitor_ips.add(ip)

    # Track request times for DDOS detection
    now = time.time()
    request_log.setdefault(ip, [])
    request_log[ip].append(now)
    # Keep only recent requests
    request_log[ip] = [t for t in request_log[ip] if now - t < DDOS_WINDOW]

    # DDOS detection
    if len(request_log[ip]) > DDOS_THRESHOLD:
        send_webhook(f"🌊 Possible DDOS detected from `{ip}` ({len(request_log[ip])} requests in {DDOS_WINDOW}s)")
        print(f"[ALERT] Possible DDOS detected from {ip} ({len(request_log[ip])} reqs in {DDOS_WINDOW}s)")

    # Detect suspicious payloads
    lowered = path.lower()
    suspicious_markers = ["'", '"', ";", "--", "<script>", "union select", "drop table", "../", "%3c", "%3e"]
    if any(x in lowered for x in suspicious_markers):
        send_webhook(f"🚨 Suspicious request detected from `{ip}` → `{method} {path}`")
        print(f"[ALERT] Suspicious request from {ip} -> {method} {path}")
    else:
        send_webhook(f"📩 {method} `{path}` from `{ip}` using `{ua}`")

@app.after_request
def log_response_info(response):
    """Log after response is sent."""
    ip = request.headers.get("X-Forwarded-For", request.remote_addr)
    if response.status_code >= 400:
        error_log[ip] = error_log.get(ip, 0) + 1
        if error_log[ip] >= ERROR_THRESHOLD:
            send_webhook(f"🔑 Brute force / suspicious errors from `{ip}` ({error_log[ip]} errors)")
            print(f"[ALERT] High error rate from {ip}: {error_log[ip]} errors")
    send_webhook(f"✅ Response {response.status_code} for `{request.path}`")
    return response

@app.errorhandler(404)
def not_found(e):
    ip = request.headers.get("X-Forwarded-For", request.remote_addr)
    error_log[ip] = error_log.get(ip, 0) + 1
    send_webhook(f"⚠️ 404 Error: `{request.path}` not found (from {ip})")
    return "404 - Page not found", 404

@app.route('/')
def home():
    return "Hello from bot-hosting.net! 🚀"

@app.route('/about')
def about():
    return "This is the about page!"

# Heartbeat
def heartbeat():
    while True:
        time.sleep(300)  # every 5 minutes
        url = get_public_url()
        send_webhook(
            f"💓 Heartbeat: Online | {len(visitor_ips)} unique visitors | {total_requests} total requests | URL: {url}"
        )
        print(f"[HEARTBEAT] Online | {len(visitor_ips)} unique visitors | {total_requests} total requests | URL: {url}")

threading.Thread(target=heartbeat, daemon=True).start()

# Startup / shutdown
public_url_guess = get_public_url()
startup_message = f"✅ Website is now **ONLINE**! URL: {public_url_guess}"
send_webhook(startup_message)
print(startup_message)

atexit.register(lambda: (send_webhook("❌ Website is now **OFFLINE**!"), print("❌ Website is now OFFLINE!")))

if __name__ == '__main__':
    # Print the public URL on the console so you can copy it easily
    print("-" * 50)
    print("Your site should be reachable at:")
    print(get_public_url())
    print("-" * 50)
    app.run(host='0.0.0.0', port=PORT)
